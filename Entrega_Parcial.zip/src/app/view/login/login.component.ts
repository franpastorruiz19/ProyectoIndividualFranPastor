import { Component, Input, Output, EventEmitter } from '@angular/core';
/*import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from 'src/app/services/auth-service.service';
import { SharedService } from 'src/app/services/shared.service';
*/
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  public user: string = "";
  public password: string = "";
  public status: number = 0;
  public message: string = "";

  //constructor(public router: Router, private authService: AuthService, private shared: SharedService) { }

  ngOnInit() {
    localStorage.clear();
  }
/*
  public onSubmit() {
    this.authService.login(this.user, this.password).pipe(
      catchError((error) => {
        this.status = error.status;
        return throwError(() => new Error(error));
      })
    ).subscribe((response: any) => {
      this.status = response.status;
      if (this.status == 200) {
        console.log(response)
        localStorage.setItem('user', this.user);
        this.shared.user.emit(localStorage.getItem('user'));
        this.router.navigate(['home']);
      }
    })
  }

  public wrongCredentials() {
    if (this.status == 401) {
      this.message = "Usuario o contraseña incorrectos, vuelva a intentarlo."
    } return this.message;
  }

  */
}

